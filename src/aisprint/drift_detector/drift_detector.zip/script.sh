#!/bin/sh

echo "SCRIPT: Running Drift Detector" 

cd /opt/drift_detector/
python main.py 